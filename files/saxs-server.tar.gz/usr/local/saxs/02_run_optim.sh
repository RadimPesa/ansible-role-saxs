#!/bin/bash
set -u

source common
source /etc/saxs.conf

if [ $# -ne 1 ]; then
	echo "Missing request id argument"
	exit "${RETURN_SERVER_ERROR}"
fi

request_id=$1
request_dir="${REQUESTS_DIR}/${request_id}"
source ${request_dir}/params.txt

request_id_safe=$(echo ${request_id} | tr '/' ':')

qsub_options=(${OPTIM_QSUB_ARGS} -N "saxsd[${request_id_safe}:optim_job]" -v "request_id=${request_id}" -w "${request_dir}/workdir" "/usr/local/saxs/optim_job.sh")

job_id="$(qsub "${qsub_options[@]}")"
[ $? -eq 0 ] || exit_error "${RETURN_SERVER_ERROR}" "Cannot submit job to PBS: qsub" "${qsub_options[@]}"

log_info "Submitted to PBS: saxsd[${request_id_safe}:optim_job] (${job_id})"

echo "queued" > "${request_dir}/status.txt"

cd "${request_dir}"
while true; do
	job_state="$(qstat -f "${job_id}" | grep "job_state" | sed 's/.*= //')"

	if [ "${job_state}" = "R" ]; then
		echo "running" > "${request_dir}/status.txt"
	fi

	if [ "${job_state}" = "C" ]; then
		job_exit_code="$(qstat -f "${job_id}" | grep "exit_status" | sed 's/.*= //')"
		[ "${job_exit_code}" -eq 0 ] || exit_error "${RETURN_SERVER_ERROR}" "Job execution was unsuccessful: ${job_id}"

		log_info "PBS job ended successfully (${job_id})"

		# Results and computed curves are ready, post-process
		tar --overwrite -xf ComputedCurves.tar
		chgrp -R apache * &>/dev/null
                chmod -R g+rwX * &> /dev/null
		break
	else
		sleep "${OPTIM_JOBS_CHECK_INTERVAL}"
	fi
done

exit "${RETURN_OK}"
