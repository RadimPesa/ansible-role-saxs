#!/bin/bash
set -u

source common
source /etc/saxs.conf

if [ $# -ne 1 ]; then
	echo "Missing request id argument"
	exit "${RETURN_SERVER_ERROR}"
fi

request_id=$1
request_dir="${REQUESTS_DIR}/${request_id}"

[ "${CLEAN_AFTER_SUCCESS}" = "false" ] && exit "${RETURN_OK}"

# clean local things
rm -rf "${request_dir}/workdir" || exit_error "${RETURN_SERVER_ERROR}" "Cannot cleanup local files in the request directory"

exit "${RETURN_OK}"
